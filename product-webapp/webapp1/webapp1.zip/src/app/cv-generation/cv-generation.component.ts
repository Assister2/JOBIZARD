import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-generation',
  templateUrl: './cv-generation.component.html',
  styleUrls: ['./cv-generation.component.css']
})
export class CvGenerationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
