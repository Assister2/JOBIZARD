import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-template1',
  templateUrl: './cv-template1.component.html',
  styleUrls: ['./cv-template1.component.css']
})
export class CvTemplate1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
