import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-template2',
  templateUrl: './cv-template2.component.html',
  styleUrls: ['./cv-template2.component.css']
})
export class CvTemplate2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
