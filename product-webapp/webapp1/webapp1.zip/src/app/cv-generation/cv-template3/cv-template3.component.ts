import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-template3',
  templateUrl: './cv-template3.component.html',
  styleUrls: ['./cv-template3.component.css']
})
export class CvTemplate3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
