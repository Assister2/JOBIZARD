import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';

@Component({
  selector: 'app-assesment-portal',
  templateUrl: './assesment-portal.component.html',
  styleUrls: ['./assesment-portal.component.css']
})
export class AssesmentPortalComponent implements OnInit{
  
   constructor(){
   }
  ngOnInit(): void {
   
  }
}
