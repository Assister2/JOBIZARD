export class JobSeeker
{
    emailId: string="";
    firstName: string="";
    middleName: string="";
    lastName: string="";
    gender: string="";
    dateOfBirth: string="";
    mobileNumber: number=0;
    password: string="";
    jobSeekerImage: any ="";

    constructor()
    {
        this.emailId="";
        this.firstName="";
        this.middleName="";
        this.lastName="";
        this.gender="";
        this.dateOfBirth="";
        this.mobileNumber;
        this.password="";
        this.jobSeekerImage="";
    }
}