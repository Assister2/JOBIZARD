export class OrganizationDetails
{
    organizationID!: string
    organizationName!: string
    organizationSector!: string
    rganizationOrigin!: string
    roleInHiring!: string
    organizationAddress!: string
    contactNumber!: number
    organizationLogo!: any
}