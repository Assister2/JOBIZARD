export class jobPost{
    companyName:string="";
    companyUrl:string="";
    companyEmail:string="";
    industryType:string="";
    companyLogo:any;
    jobRole:string="";
    salary:any="";
    jobDescription:string="";
    location:string="";
    lastDate:string="";
    eduation:string="";
    experience:string="";
    skills:any=[];
    // list getJobDetailsList = 

    constructor(){
        this.companyName="";
        this.companyUrl="";
        this.companyEmail="";
        this.industryType="";
        this.companyLogo="";
        this.jobRole="";
        this.salary="";
        this.jobDescription="";
        this.location="";
        this.lastDate="";
        this.eduation="",
        this.experience="",
        this.skills="";
    }
}