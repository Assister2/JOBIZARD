export class SkillTrend {

    skillId:any;
    onDemandSkills!:String;
    industryName!:string;
    year!:number;
    skillDemandedByCompany!:number;
    
}
