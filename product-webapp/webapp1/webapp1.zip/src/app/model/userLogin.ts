export class UserLogin
{
    emailId: string="";
    password: string="";

    constructor()
    {
        this.emailId="";
        this.password="";
    }
}