import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assesment-test-portal',
  templateUrl: './assesment-test-portal.component.html',
  styleUrls: ['./assesment-test-portal.component.css']
})
export class AssesmentTestPortalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
