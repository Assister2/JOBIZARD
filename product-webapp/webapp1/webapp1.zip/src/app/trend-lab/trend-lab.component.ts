import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trend-lab',
  templateUrl: './trend-lab.component.html',
  styleUrls: ['./trend-lab.component.css']
})
export class TrendLabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
